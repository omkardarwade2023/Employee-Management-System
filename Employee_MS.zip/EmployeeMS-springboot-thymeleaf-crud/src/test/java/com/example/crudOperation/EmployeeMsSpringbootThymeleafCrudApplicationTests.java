package com.example.crudOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMsSpringbootThymeleafCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
